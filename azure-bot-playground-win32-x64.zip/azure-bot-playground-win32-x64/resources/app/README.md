## Azure Bot 4.0 Plyground
### A tool to create and preview Bot with Azure Bot 4.0

Here is a screenshot
![screenshot](/quick-start.gif)

Download it.


https://github.com/maye-msft/azure-bot-playground/raw/master/azure-bot-playground-win32-x64.zip